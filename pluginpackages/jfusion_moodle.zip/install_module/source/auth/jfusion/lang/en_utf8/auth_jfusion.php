<?php // $Id: auth_jfusion.php,v 1.1 2011/07/17 21:28:00 hwevers Exp $
$string['auth_jfusiondescription'] = 'JFusion DSSO support. Make sure this plugin is the last in line of all active auth plugins. For setup instructions see the document \"CURL setup\" on JFusions website (www.jfusion.org)';
$string['auth_jfusiontitle'] = 'JFusion';
$string['auth_jfusion_enabled'] = 'Enabled';
$string['auth_jfusion_ismaster'] = 'Master';
$string['auth_jfusion_fullpath'] = 'Full directory path to Joomla';
$string['auth_jfusion_baseurl'] = 'Joomla BaseURL';
$string['auth_jfusion_loginpath'] = 'Joomla Loginpath';
$string['auth_jfusion_logoutpath'] = 'Joomla Logoutpath';
$string['auth_jfusion_formid'] = 'Joomla Loginform formid';
$string['auth_jfusion_relpath'] = 'Joomla Loginform relpath';
$string['auth_jfusion_cookiedomain'] = 'Joomla Cookiedomain';
$string['auth_jfusion_cookiepath'] = 'Joomla Cookiepath';
$string['auth_jfusion_username_id'] = 'Joomla Loginform usernameid';
$string['auth_jfusion_password_id'] = 'Joomla Loginform passwordid';
$string['auth_jfusion_cookie_secure'] = 'Joomla Cookie secure setting';
$string['auth_jfusion_cookie_httponly'] = 'Joomla Cookie httponly setting';
$string['auth_jfusion_verifyhost'] = 'Curl veryfy host';
$string['auth_jfusion_leavealone'] = 'Cookies to leavealone';
$string['auth_jfusion_postfields'] = 'Fields to post for logout';
$string['auth_jfusion_expires'] = 'Cookie exiration time';

$string['auth_jfusion_enabled_help'] = '';
$string['auth_jfusion_ismaster_help'] = '';
$string['auth_jfusion_fullpath_help'] = '';
$string['auth_jfusion_baseurl_help'] = '';
$string['auth_jfusion_loginpath_help'] = '';
$string['auth_jfusion_logoutpath_help'] = '';
$string['auth_jfusion_formid_help'] = '';
$string['auth_jfusion_relpath_help'] = '';
$string['auth_jfusion_cookiedomain_help'] = '';
$string['auth_jfusion_cookiepath_help'] = '';
$string['auth_jfusion_username_id_help'] = '';
$string['auth_jfusion_password_id_help'] = '';
$string['auth_jfusion_cookie_secure_help'] = '';
$string['auth_jfusion_cookie_httponly_help'] = '';
$string['auth_jfusion_verifyhost_help'] = '';
$string['auth_jfusion_leavealone_help'] = '';
$string['auth_jfusion_postfields_help'] = '';
$string['auth_jfusion_expires_help'] = 'seconds';

?>